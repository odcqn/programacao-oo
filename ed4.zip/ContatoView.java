public class ContatoView {
    public void mostrarContato(Contato contato) {
        System.out.println(contato);
    }
}