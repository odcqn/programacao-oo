public interface Contato {
    String getNome();
    String getTelefone();
    String getEmail();
    String getDocumento();
    String toString();
}